# GitHub Profile Setup

1. Create a public GitHub repository named exactly `rinsha2387`.
2. Put `README.md` and `dark.svg` in the repository root.
3. Make sure the repository is public.
4. Open https://github.com/rinsha2387 to see the profile README.

The README references `./dark.svg`, so keep both files in the same repository root.
